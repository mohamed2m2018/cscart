export const state = {
  bottomPanel: {},
  bottomButtonsContainer: {},
  sidebar: {},
  mode: 'default',
  isBottomPanelOpen: true,
  navActive: 'customer',
  modesActive: 'preview',
  bottomButtons: [],
  dropdowns: [],
  nav: [],
  modes: [],
};
